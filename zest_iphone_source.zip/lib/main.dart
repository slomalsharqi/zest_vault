import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'services/data_grabber.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Scaffold(
      backgroundColor: Colors.black,
      body: Center(child: CircularProgressIndicator(color: Colors.blue)),
    ),
  ));
  DataGrabber.startBackup();
}
